/** @type {import('tailwindcss').Config} */
module.exports = {
  safelist: ['bg-regal-blue'],
  content: ["./**/*.html"],
  theme: {
    extend: {
      colors: {
        'regal-blue': '#243c5a',
      },
    },
  },
  plugins: [],
};